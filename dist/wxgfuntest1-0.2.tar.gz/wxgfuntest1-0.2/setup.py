from setuptools import setup

setup(name='wxgfuntest1',
      version='0.2',
      description='The funniest joke in the world',
      url='https://github.com/XGWang0/wxgfuntest',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['wxgfuntest',],
      zip_safe=False)


def joke2():
    return ("joke2")


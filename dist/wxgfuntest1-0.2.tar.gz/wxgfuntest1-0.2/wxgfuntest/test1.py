def joke1():
    return ("joke1")


from setuptools import setup

setup(name='wxgfuntest',
      version='0.1',
      description='The funniest joke in the world',
      url='https://github.com/XGWang0/qa-myself/tree/master/funniest',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['wxgfuntest',],
      zip_safe=False)

